// Interactive Elements
const profileForm = document.getElementById('profileForm');
const saveBtn = document.querySelector('.save-btn');
const removeButtons = document.querySelectorAll('.remove-btn');
const emptyCartMsg = document.getElementById('emptyCartMsg');
const cartList = document.getElementById('cartList');

// --- Profile Update Simulation ---
profileForm.addEventListener('submit', (e) => {
    e.preventDefault(); 
    
    // In a real app, you'd send the updated values to Firebase here
    const newAddress = document.getElementById('userAddress').value;
    
    alert('Profile successfully updated in the database! ✨');
});

// --- Material You Click Ripple Effect for the Save Button ---
saveBtn.addEventListener('click', function(e) {
    const circle = document.createElement('span');
    const diameter = Math.max(this.clientWidth, this.clientHeight);
    const radius = diameter / 2;

    const rect = this.getBoundingClientRect();
    circle.style.width = circle.style.height = `${diameter}px`;
    circle.style.left = `${e.clientX - rect.left - radius}px`;
    circle.style.top = `${e.clientY - rect.top - radius}px`;
    circle.classList.add('ripple');

    const ripple = this.getElementsByClassName('ripple')[0];
    if (ripple) {
        ripple.remove();
    }

    this.appendChild(circle);
});

// --- Remove Items from Cart with Animation ---
removeButtons.forEach(btn => {
    btn.addEventListener('click', function() {
        // Find the parent item card
        const itemCard = this.closest('.cart-item');
        
        // Add fade-out animation class
        itemCard.classList.add('fade-out');
        
        // Wait for CSS transition to finish before removing from DOM
        setTimeout(() => {
            itemCard.remove();
            checkEmptyCart();
        }, 300); // Matches the 0.3s transition in CSS
    });
});

// --- Check if Cart is Empty to show message ---
function checkEmptyCart() {
    // Count how many cart items are left
    const remainingItems = cartList.querySelectorAll('.cart-item').length;
    
    if (remainingItems === 0) {
        emptyCartMsg.style.display = 'block';
    }
}