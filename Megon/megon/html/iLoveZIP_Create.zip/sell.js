// Interactive Elements
const imageUpload = document.getElementById('imageUpload');
const fileLabelText = document.getElementById('file-label-text');
const sellForm = document.getElementById('sellForm');
const buttons = document.querySelectorAll('.btn');
const discardBtn = document.querySelector('.discard-btn');

// --- Feature: Update Label when an image is selected ---
imageUpload.addEventListener('change', function(e) {
    if (e.target.files && e.target.files.length > 0) {
        const fileName = e.target.files[0].name;
        const shortName = fileName.length > 25 ? fileName.substring(0, 22) + '...' : fileName;
        
        fileLabelText.textContent = `Selected: ${shortName}`;
        document.querySelector('.upload-icon').textContent = '✅';
    } else {
        fileLabelText.textContent = 'Tap to browse & attach an image (Optional)';
        document.querySelector('.upload-icon').textContent = '📷';
    }
});

// --- Material You Click Ripple Effect for all Buttons ---
buttons.forEach(btn => {
    btn.addEventListener('click', function(e) {
        const circle = document.createElement('span');
        const diameter = Math.max(this.clientWidth, this.clientHeight);
        const radius = diameter / 2;

        const rect = this.getBoundingClientRect();
        circle.style.width = circle.style.height = `${diameter}px`;
        circle.style.left = `${e.clientX - rect.left - radius}px`;
        circle.style.top = `${e.clientY - rect.top - radius}px`;
        circle.classList.add('ripple');

        const ripple = this.getElementsByClassName('ripple')[0];
        if (ripple) {
            ripple.remove();
        }

        this.appendChild(circle);
    });
});

// --- Discard Form Feature ---
discardBtn.addEventListener('click', () => {
    if(confirm('Are you sure you want to discard this listing?')) {
        sellForm.reset(); 
        fileLabelText.textContent = 'Tap to browse & attach an image (Optional)';
        document.querySelector('.upload-icon').textContent = '📷';
    }
});

// --- Mock Form Submission ---
sellForm.addEventListener('submit', (e) => {
    e.preventDefault(); 
    
    alert('Product logged! Ready to send to Firebase backend. 🚀');
});